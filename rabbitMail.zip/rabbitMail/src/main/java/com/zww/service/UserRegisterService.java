package com.zww.service;

/**
 * Created by zhaoww on 2018/3/7.
 */
public interface UserRegisterService {
    String userRegister();
    String userRegisterFanout();
    String userRegisterDirect();
    String userRegisterTopic();
}
