package com.zww;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitMailApplication.class, args);
	}
}
